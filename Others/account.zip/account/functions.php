<?php
// ACCOUNT
// Register
function vc_register_user() {
	$err = '';
	$success = '';
	global $wpdb, $PasswordHash, $current_user, $user_ID;
	if (isset($_POST['task']) && $_POST['task'] == 'register') {
		$_SESSION['err'] = '';
		$pwd1 = $wpdb->escape(trim($_POST['pwd1']));
		$pwd2 = $wpdb->escape(trim($_POST['pwd2']));
		$first_name = $wpdb->escape(trim($_POST['first_name']));
		$last_name = $wpdb->escape(trim($_POST['last_name']));
		$email = $wpdb->escape(trim($_POST['email']));
		$username = $wpdb->escape(trim($_POST['username']));
		if ($email == "" || $pwd1 == "" || $pwd2 == "" || $username == "" || $first_name == "" || $last_name == "") {
			$err = 'Please don\'t leave empty the required fields.';
		} else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$err = 'Invalid e-mail address.';
		} else if (email_exists($email)) {
			$err = 'E-mail already exist.';
		} else if ($pwd1 <> $pwd2){
			$err = 'Password do not match.';
		} else {
			$user_id = wp_insert_user( array ('first_name' => apply_filters('pre_user_first_name', $first_name), 'last_name' => apply_filters('pre_user_last_name', $last_name), 'user_pass' => apply_filters('pre_user_user_pass', $pwd1), 'user_login' => apply_filters('pre_user_user_login', $username), 'user_email' => apply_filters('pre_user_user_email', $email), 'role' => 'subscriber' ) );
			if (is_wp_error($user_id)) {
				$err = 'Error on user creation.';
			} else {
				do_action('user_register', $user_id);
				$creds = array(
					'user_login' => $username,
					'user_password' => $pwd1,
					'remember' => true
				);
				$signed = wp_signon($creds, true);
				wp_set_current_user($user_id);
				/*$user = get_user_by('id', $user_id);
	                if (!in_array('author', $user->roles)) {
	                    $user->add_role('author');
	                }
				}*/
				wp_redirect(home_url('/')); die();
				//$success = 'You\'re successfully registered!';
			}
		}
		//exit();
		if (!empty($err))	{
			$_SESSION['err'] = $err;
		}
	}
}
add_action('init', 'vc_register_user');

// Login
function vc_login_user() {
	global $wpdb;
	$err = '';
	$success = '';
	if (isset($_POST['task']) && $_POST['task'] == 'login')
	{
		$username = $wpdb->escape($_POST['log']);
		$password = $wpdb->escape($_POST['pwd']);
		$remember = $wpdb->escape($_POST['remember']);
		if ($remember) { $remember = "true"; } else { $remember = "false"; }
		if ($username == "" || $password == "") {
			$err = 'Please don\'t leave fields empty.';
		} else {
			/*$user_data = array();
			$user_data['user_login'] = $username;
			$user_data['user_password'] = $password;
			$user_data['remember'] = $remember;*/
			$user_data = array(
				'user_login' => $username,
				'user_password' => $password,
				'remember' => $remember
			);
			$user = wp_signon( $user_data, false );
			wp_redirect(esc_url(site_url())); die();
			if (is_wp_error($user)) {
				$err = $user->get_error_message();
				exit();
			} else {
				wp_set_current_user( $user->ID, $username );
				do_action('set_current_user');
				//wp_redirect(esc_url(site_url())); die();
			}
		}
	}
}
add_action('init', 'vc_login_user');
?>