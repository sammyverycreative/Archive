<?php
/*
Template Name: Login
*/
get_header();
?>

<?php
$current_user = wp_get_current_user();
$user = $current_user->user_login;
$email = $current_user->user_email;
$fname = $current_user->user_firstname;
$lname = $current_user->user_lastname;
$name = $current_user->display_name;
$uID = $current_user->ID;
?>

<div class="white">
	<div class="container">
		<div class="static-page general auth-page">
	        <?php /*<h2><?php the_title(); ?></h2>*/ ?>
	        <div class="the-content">
				<?php /*
				if (is_user_logged_in()) {
				    echo 'Debug: Logged User';
				} else {
				    echo 'Debug: Guest';
				}
				*/ ?>
				<?php if (!is_user_logged_in()) { ?>
					<form method="post">
						<h2>Already have an account? Please login.</h2>
						<p>
							<?php
							if (!empty($sucess))
								echo $sucess;
							if (!empty($err))
								echo $err;
							?>
						</p>
						<p><label for="log">Username</label><br />
							<input type="text" name="log" id="log" value="" /></p>
						<p><label for="pwd">Password</label><br />
							<input type="password" name="pwd" id="pwd" value="" /></p>
						<p><input type="submit" value="Login" class="button" /></p>

						<label><input type="checkbox" name="remember" value="true" /> Remember Me</label>
						<input type="hidden" name="task" value="login" />
					</form>
					&nbsp;
					<p>If you don't remember your password reset it <a href="<?php echo esc_url(site_url()); ?>/reset">here</a>.</p>
				<?php } else { ?>
					<p>You are already logged with <strong><?php echo $user ?></strong>. Go to your <a href="<?php echo esc_url(site_url()); ?>/profile"><u>profile</u></a> page.</p>
				<?php } ?>
			</div>
	        </div>
	    </div>
	</div>
</div>

<?php get_footer() ?>