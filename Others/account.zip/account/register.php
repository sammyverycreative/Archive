 <?php
 /**
  * Template Name: Register
  */
get_header();
?>

<div class="white">
	<div class="container">
		<div class="static-page general auth-page">
	        <?php /*<h2><?php the_title(); ?></h2>*/ ?>
	        <div class="the-content">
				<?php /*
				if (is_user_logged_in()) {
				    echo 'Debug: Logged User';
				} else {
				    echo 'Debug: Guest';
				}
				*/ ?>
				<form class="custom-form" id="register-form" method="post">
					<h3>Don't have an account?<br /> Create one now.</h3>
					<p class="half left-side"><label>First Name *</label><br />
					<input type="text" value="" name="first_name" id="first_name" /></p>
					<p class="half right-side"><label>Last Name *</label><br />
					<input type="text" value="" name="last_name" id="last_name" /></p>
					<p class="half left-side"><label>E-mail *</label><br />
					<input type="text" value="" name="email" id="email" /></p>
					<p class="half right-side"><label>Username *</label><br />
					<input type="text" value="" name="username" id="username" /></p>
					<p class="half left-side"><label>Password *</label><br />
					<input type="password" value="" name="pwd1" id="pwd1" /></p>
					<p class="half right-side"><label>Password again *</label><br />
					<input type="password" value="" name="pwd2" id="pwd2" /></p>
					<div id="message">
						<?php
							if (!empty($_SESSION['err'])) :
								echo '<p class="error">'.$_SESSION['err'].'</p>';
							endif;
						?>
					</div>
					<button type="submit" name="btnregister" class="button register-btn" >Register</button>
					<input type="hidden" name="task" value="register" />
				</form>
	        </div>
	    </div>
	</div>
</div>

<?php get_footer() ?>