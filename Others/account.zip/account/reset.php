<?php
/*
Template Name: Reset
*/
get_header()
?>

<div class="white">
	<div class="container">
		<div class="static-page general auth-page">
	        <?php /*<h2><?php the_title(); ?></h2>*/ ?>
	        <div class="the-content">
				<?php
					global $wpdb;
					$error = '';
					$success = '';
					if (isset( $_POST['action'] ) && 'reset' == $_POST['action'])
					{
						$email = trim($_POST['user_login']);
						if (empty($email)) {
							$error = 'Enter e-mail address.';
						} else if (!is_email($email)) {
							$error = 'Invalid e-mail address.';
						} else if (!email_exists($email)) {
							$error = 'There is no username registered with that e-mail address.';
						} else {
							$random_password = wp_generate_password( 12, false );
							$user = get_user_by('email', $email);
							$update_user = wp_update_user( array (
									'ID' => $user->ID,
									'user_pass' => $random_password
								)
							);
							if($update_user) {
								$to = $email;
								$subject = 'New Password';
								$sender = get_option('name');
								$message = 'Your new password is: '.$random_password;
								$headers[] = 'MIME-Version: 1.0' . "\r\n";
								$headers[] = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
								$headers[] = "X-Mailer: PHP \r\n";
								$headers[] = 'From: '.$sender.' < '.$email.'>' . "\r\n";
								$mail = wp_mail( $to, $subject, $message, $headers );
								if ($mail)
									$success = 'Check your e-mail address for you new password.';
							} else {
								$error = 'Oops... Something went wrong updaing your account.';
							}
						}
					}
				?>

				<form method="post">
					<fieldset>
						<p style="font-weight: bold;">Please enter your e-mail address. You will receive the new password via e-mail.</p>
						<p><label for="user_login">E-mail</label><br />
							<?php $user_login = isset( $_POST['user_login'] ) ? $_POST['user_login'] : ''; ?>
							<input type="text" name="user_login" id="user_login" value="<?php echo $user_login; ?>" /></p>
						<p>
							<input type="hidden" name="action" value="reset" />
							<?php if (empty($error) && empty($success)) { ?><input type="submit" value="Reset Password" class="button" id="submit" /><?php } ?>
						</p>
					</fieldset>
				</form>

				<?php 
				if (!empty($error))
					echo '<div class="message"><p class="error">'. $error .'</p></div>';
				if (!empty($success))
					echo '<div class="error_login"><p class="success">'. $success .'</p></div>';
				?>
			</div>
	    </div>
	</div>
</div>

<?php get_footer() ?>